setwd("")
setwd("C:\\Users\\sades\\OneDrive\\Desktop\\IT24102346_PS_LAB 5")

Delivery_Times<-read.table("Exercise - Lab 05.txt",header=TRUE,sep=",")

histogram <- hist(Delivery_Times$DeliveryTime,
                  main = "Histogram for Delivery Times",
                  breaks = seq(20, 70, length = 10),
                  right=FALSE)

str(Delivery_Times)

hist(Delivery_Times$Delivery_Time_.minutes.,
     main = "Histogram for Delivery Times",
     breaks = seq(20, 70, length = 10),  # 9 class intervals
     right = FALSE,
     )


## Part 5 - Ogive for Delivery Times

breaks <- seq(20, 70, length.out = 10)

cuts <- cut(Delivery_Times$Delivery_Time_.minutes.,
            breaks = breaks,
            right = FALSE,
            include.lowest = TRUE)


freq <- table(cuts)
cum.freq <- cumsum(freq)


new <- c()


for(i in 1:length(breaks)){
  if(i == 1){
    new[i] <- 0
  } else {
    new[i] <- cum.freq[i-1]
  }
}

plot(breaks, new, type = "l",
     main = "Cumulative Frequency Polygon for Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     ylim = c(0, max(cum.freq)),
     )

cbind(Upper = breaks, CumFreq = new)


