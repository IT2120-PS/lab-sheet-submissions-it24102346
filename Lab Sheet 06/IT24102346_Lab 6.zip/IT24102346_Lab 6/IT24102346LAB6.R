setwd("C:\\Users\\sades\\OneDrive\\Desktop\\IT24102346_Lab 6")

#Here,random variable X has binomial distribution with n=50 and p=0.85

1-pbinom(46,50,0.85,lower.tail=TRUE)


#number of calls received in one hour
#Here,random variable Xhas poisson distribution with lambda=12

dpois(15,12)

